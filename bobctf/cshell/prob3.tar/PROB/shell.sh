#!/bin/bash
export SHELL=/bin/bash	
/usr/bin/python2.7 /customShell.py
